# SmartBuildings

## Back-end [README](./back-end/README.md)
## Front-end [README](./front-end/README.md)