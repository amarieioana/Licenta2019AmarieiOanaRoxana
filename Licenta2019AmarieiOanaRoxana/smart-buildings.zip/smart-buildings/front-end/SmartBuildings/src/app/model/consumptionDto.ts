export class ConsumptionDto{

    id: string;
    product: string;
    floor: string;
    consumedQuantity: number;
    supplyDate: string;
   
}