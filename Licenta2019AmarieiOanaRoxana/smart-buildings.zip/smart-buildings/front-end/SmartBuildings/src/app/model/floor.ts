import { Consumption } from './consumption';

export class Floor{
    floor: string;
    consumptions: Array<Consumption>;
}