import { Floor } from './floor';

export class Product{
    name: string;
    floors: Array<Floor>;
}