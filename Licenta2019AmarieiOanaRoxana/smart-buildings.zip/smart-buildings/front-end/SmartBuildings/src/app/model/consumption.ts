export class Consumption{
    consumedQuantity: number;
    supplyDate: string;
}