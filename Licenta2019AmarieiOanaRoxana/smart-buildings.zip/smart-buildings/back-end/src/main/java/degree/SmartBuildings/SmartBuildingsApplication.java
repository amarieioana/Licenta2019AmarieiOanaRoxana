package degree.SmartBuildings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartBuildingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartBuildingsApplication.class, args);
	}

}
